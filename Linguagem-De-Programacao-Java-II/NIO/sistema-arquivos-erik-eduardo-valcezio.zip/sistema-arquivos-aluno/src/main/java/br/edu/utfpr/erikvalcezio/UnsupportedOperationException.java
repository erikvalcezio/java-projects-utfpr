package br.edu.utfpr.erikvalcezio;

/**  
* 
* @version 1.0.0
* @author Erik Eduardo Valcezio 
*
*/

public class UnsupportedOperationException extends RuntimeException {

    public UnsupportedOperationException(String message) {
        super(message);
    }
}