package br.org.utfpr.repository;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import br.org.utfpr.repository.service.CrudDepartamentoService;
import br.org.utfpr.repository.service.CrudFuncionarioService;
import br.org.utfpr.repository.service.RelatoriosService;


@EnableJpaRepositories
@ComponentScan(basePackages = {"br.org.utfpr.repository"})
@SpringBootApplication
public class SpringDataApplication implements CommandLineRunner {
	/**
	 * Classe principal da aplicação.
	 */

	private Boolean system = true;	
	
	private final CrudDepartamentoService departamentoService;
	
	private final CrudFuncionarioService funcionarioService;
	
	private final RelatoriosService relatoriosService;	
		
	@Autowired
	public SpringDataApplication(CrudDepartamentoService departamentoService,
			CrudFuncionarioService funcionarioService,
			RelatoriosService relatoriosService) {
		this.departamentoService = departamentoService;	
		this.funcionarioService = funcionarioService;
		this.relatoriosService = relatoriosService;	
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringDataApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Scanner scanner = new Scanner(System.in);

		while (system) {
			System.out.println("Selecione a função desejada?");
			System.out.println("0 - Sair");
			System.out.println("1 - Departamento");
			System.out.println("2 - Funcionario");
			System.out.println("3 - Relatorios");

			Integer function = scanner.nextInt();

			switch (function) {
				case 1:
					departamentoService.inicial(scanner);
					break;
				case 2:
					funcionarioService.inicial(scanner);
					break;	
				case 3:
					relatoriosService.inicial(scanner);
					break;
				default:
					System.out.println("Finalizando");
					system = false;
					break;
			}
		}
	}
}