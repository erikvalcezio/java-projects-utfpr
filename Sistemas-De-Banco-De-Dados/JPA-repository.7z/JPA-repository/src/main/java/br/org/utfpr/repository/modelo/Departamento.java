package br.org.utfpr.repository.modelo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "departamentos")
public class Departamento{
	/**
	 * Model Departamento
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cod_dpto", length = 64, nullable = false)
	private @Getter @Setter Long codigoDepartamento;
	
	@Column(name = "nome_dpto", length = 64, nullable = false)
	private @Getter @Setter String nome;	
	
	@OneToMany(mappedBy = "departamento")
	private @Getter @Setter List<Funcionario> funcionario;	
	
	@Override
	public String toString() {
		return "Departamento [ Código departamento= " + codigoDepartamento  + ", Nome do Departamento : " + nome + " ]";
	}

}
