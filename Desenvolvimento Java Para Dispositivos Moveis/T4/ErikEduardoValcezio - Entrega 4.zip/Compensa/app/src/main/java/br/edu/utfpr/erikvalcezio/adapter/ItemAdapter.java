package br.edu.utfpr.erikvalcezio.adapter;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import br.edu.utfpr.erikvalcezio.R;
import br.edu.utfpr.erikvalcezio.model.Produto;

public class ItemAdapter extends RecyclerView.Adapter <ItemAdapter.myHolderView>  {

    private Context context;
    private List<Produto> produtosList;

    public ItemAdapter(Context context, List<Produto> produtos) {
        this.context = context;
        this.produtosList = produtos;
    }

    @NonNull
    @Override
    public myHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.linha_item_produto,
                                                                      parent,
                                                                      false);
        return new myHolderView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myHolderView holder, int position) {
        int posicao = position;
        holder.prodDesc.setText(produtosList.get(posicao).getDescricao());
        holder.prodPreco.setText(String.valueOf(produtosList.get(posicao).getPreco()));
        holder.prodQtd.setText(String.valueOf(produtosList.get(posicao).getQuantidade()));
        holder.prodTipo.setText(produtosList.get(posicao).getNomeUnidade());
        holder.prodTotal.setText(produtosList.get(posicao).somarTotal());

        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, String.format("%s %s %s",
                                                        context.getString(R.string.item),
                                                        produtosList.get(posicao).getDescricao() ,
                                                        context.getString(R.string.selecionado)),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return produtosList.size();
    }

    public class myHolderView extends RecyclerView.ViewHolder  implements View.OnCreateContextMenuListener {
        private TextView prodDesc, prodPreco, prodQtd, prodTipo, prodTotal;
        public ConstraintLayout constraintLayout;

        public myHolderView(@NonNull View itemView) {
            super(itemView);
            this.prodDesc = itemView.findViewById(R.id.textViewRecProdDesc);
            this.prodPreco = itemView.findViewById(R.id.textViewRecProdPreco);
            this.prodQtd = itemView.findViewById(R.id.textViewRecProdQtd);
            this.prodTipo = itemView.findViewById(R.id.textViewRecProdTipo);
            this.prodTotal = itemView.findViewById(R.id.textViewRecProdTotal);
            this.constraintLayout = itemView.findViewById(R.id.layout_constrain_linha_it_prod);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
            contextMenu.add(this.getAdapterPosition(), R.id.MenuItemEditar, 0, R.string.editar);
            contextMenu.add(this.getAdapterPosition(), R.id.MenuItemLimpar,1, R.string.excluir);
        }
    }
}

