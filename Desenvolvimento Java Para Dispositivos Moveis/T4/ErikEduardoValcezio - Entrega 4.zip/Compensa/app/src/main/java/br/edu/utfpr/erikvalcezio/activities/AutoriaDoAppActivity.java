package br.edu.utfpr.erikvalcezio.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import br.edu.utfpr.erikvalcezio.R;

public class AutoriaDoAppActivity extends AppCompatActivity {
    private TextView nomeAlunoText, cursoAlunoText, emailAlunoText, descricaoAplicativoText;
    private ImageView imageUTFPR;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autoria_do_app);

        setTitle(getString(R.string.app_name) + getString(R.string.espaco_app_name) + getString(R.string.autoria_do_app));

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        this.nomeAlunoText = findViewById(R.id.textViewNomeAluno);
        this.cursoAlunoText = findViewById(R.id.textViewCursoAluno);
        this.emailAlunoText = findViewById(R.id.textViewEmailAluno);
        this.descricaoAplicativoText = findViewById(R.id.textViewDescricaoApp);
        this.imageUTFPR = (ImageView) findViewById(R.id.imageViewUTFPR);
        this.imageUTFPR.setImageResource(R.drawable.logo_utfpr_original);

        this.nomeAlunoText.setText(getString(R.string.nome_aluno));
        this.cursoAlunoText.setText(getString(R.string.curso_aluno));
        this.emailAlunoText.setText(getString(R.string.email_aluno));
        this.descricaoAplicativoText.setText(getString(R.string.descricao_app_aluno));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finalizar();
                return Boolean.TRUE;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void finalizar(){
        setResult(Activity.RESULT_CANCELED);
        this.finish();
    }
}