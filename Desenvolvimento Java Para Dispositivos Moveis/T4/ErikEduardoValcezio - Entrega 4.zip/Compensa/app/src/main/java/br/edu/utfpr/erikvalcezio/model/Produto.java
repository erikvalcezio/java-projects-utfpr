package br.edu.utfpr.erikvalcezio.model;

import java.math.BigDecimal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@ToString
@EqualsAndHashCode
public class Produto {

    //private long id; // quando for usar sqlLite
    @Getter
    private String descricao;
    private BigDecimal preco;
    private int quantidade;
    private String nomeUnidade;
    private String setor; //trocar por classe Setor, futura implementação

    public Produto(){
        //default constructor
    }

    public Produto(Produto produto){
        this.descricao = produto.getDescricao();
        this.preco = produto.getPreco();
        this.quantidade = produto.getQuantidade();
        this.nomeUnidade = produto.getNomeUnidade();
        this.setor = produto.getSetor();
    }

    //public void setId(long id) { this.id = id; } // quando for usar sqlLite

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao(){
        return this.descricao;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public BigDecimal getPreco(){
        return this.preco;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getQuantidade(){
        return this.quantidade;
    }

    public void setNomeUnidade(String nomeUnidade) {
        this.nomeUnidade = nomeUnidade;
    }

    public String getNomeUnidade(){
        return this.nomeUnidade;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public String getSetor() {
        return this.setor;
    }

    public String somarTotal(){
        return  String.valueOf(this.preco.multiply(BigDecimal.valueOf(this.quantidade)));
    }

   /** public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    } implementação sqlLite **/

}