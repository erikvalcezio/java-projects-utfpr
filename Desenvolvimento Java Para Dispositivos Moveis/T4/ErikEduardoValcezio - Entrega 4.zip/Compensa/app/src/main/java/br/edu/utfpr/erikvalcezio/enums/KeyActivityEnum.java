package br.edu.utfpr.erikvalcezio.enums;

import android.content.res.Resources;

import br.edu.utfpr.erikvalcezio.R;

public enum KeyActivityEnum {
    POSICAO(R.string.key_posicao),
    DESCRICAO(R.string.key_descricao),
    PRECO(R.string.key_preco),
    QUANTIDADE(R.string.key_quantidade),
    TIPO_MEDIDA(R.string.key_tipo_medida),
    SETOR(R.string.key_setor);


    private int resID = -1;

    private KeyActivityEnum(int resID) {
        this.resID = resID;
    }

    public String getResIdToStringValue(Resources res) {
        if (-1 != resID) {
            return (res.getString(resID));
        }
        return (this.toString());
    }
}
