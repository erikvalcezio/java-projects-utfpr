package br.edu.utfpr.erikvalcezio.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


import br.edu.utfpr.erikvalcezio.R;
import br.edu.utfpr.erikvalcezio.adapter.ItemAdapter;
import br.edu.utfpr.erikvalcezio.enums.KeyActivityEnum;
import br.edu.utfpr.erikvalcezio.model.Produto;

public class ItemDespensaActivity extends AppCompatActivity {

    private List<Produto> produtoList = new ArrayList<>();
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle(getString(R.string.app_name) + getString(R.string.espaco_app_name) + getString(R.string.item_da_despensa));

        setContentView(R.layout.item_despensa);

        recyclerView = (RecyclerView) findViewById(R.id.It_produtosList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemAdapter = new ItemAdapter(this, produtoList);

        recyclerView.setAdapter(itemAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_despensa_opcoes, menu);
        return Boolean.TRUE;
    }

    public void adicionarProduto() {
        Intent intent = new Intent(ItemDespensaActivity.this, CadastroProdutoActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        if (resultCode == Activity.RESULT_OK) {
            Bundle bundle = data.getExtras();

            if (bundle != null) {
                this.produtoList.add(this.popularProduto(bundle));
                this.mostrarMensagem(getString(R.string.produto_cadastrado));
            }
        }

        if (resultCode == CadastroProdutoActivity.ALTERAR){
            Bundle bundle = data.getExtras();
            Produto produto = new Produto();
            int posicao = bundle.getInt(KeyActivityEnum.POSICAO.getResIdToStringValue(getResources()));
            produtoList.remove(posicao);
            produtoList.add(posicao , this.popularProduto(bundle));
            this.mostrarMensagem(getString(R.string.produto_editado));
        }

        if (resultCode == Activity.RESULT_CANCELED) {
            this.mostrarMensagem(getString(R.string.produto_nao_cadastrado));
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private Produto popularProduto(Bundle bundle) {
        Produto produto = new Produto();
        produto.setDescricao(bundle.getString(KeyActivityEnum.DESCRICAO.getResIdToStringValue(getResources())));
        produto.setPreco(new BigDecimal(bundle.getString(KeyActivityEnum.PRECO.getResIdToStringValue(getResources()))));
        produto.setQuantidade(bundle.getInt(KeyActivityEnum.QUANTIDADE.getResIdToStringValue(getResources())));
        produto.setNomeUnidade(bundle.getString(KeyActivityEnum.TIPO_MEDIDA.getResIdToStringValue(getResources())));
        produto.setSetor(bundle.getString(KeyActivityEnum.SETOR.getResIdToStringValue(getResources())));
        return produto;
    }


    @Override
    public void onResume() {
        super.onResume();
        itemAdapter.notifyDataSetChanged();
    }

    private void mostrarMensagem(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.MenuItemAdicionar:
                this.adicionarProduto();
                return Boolean.TRUE;
            case R.id.MenuItemSobre:
                Intent intent = new Intent(ItemDespensaActivity.this, AutoriaDoAppActivity.class);
                startActivity(intent);
                return Boolean.TRUE;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

         switch (item.getItemId()) {
             case R.id.MenuItemEditar:
                 this.editar(item.getGroupId());
                 return Boolean.TRUE;
             case R.id.MenuItemLimpar:
                 this.excluir(item.getGroupId());
                 return Boolean.TRUE;
             default:
                 return super.onContextItemSelected(item);
         }
    }

    private void editar(int posicao) {
        Produto produto = new Produto(this.produtoList.get(posicao));
        CadastroProdutoActivity.editarProduto(this, produto, posicao);
    }

    private void excluir(int posicao) {
        this.produtoList.remove(posicao);
        this.mostrarMensagem(getString(R.string.item_excluido));
        onResume();
    }
}
